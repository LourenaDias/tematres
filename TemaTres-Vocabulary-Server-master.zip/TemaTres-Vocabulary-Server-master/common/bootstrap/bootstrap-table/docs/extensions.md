---
layout: default
title: pages.extensions.title
slug: extensions
lead: pages.extensions.lead
---

{% tf extensions/editable.md %}

{% tf extensions/export.md %}

{% tf extensions/flatJSON.md %}

{% tf extensions/cookie.md %}

{% tf extensions/resizable.md %}

{% tf extensions/reorder.md %}

{% tf extensions/filter.md %}

{% tf extensions/keyevents.md %}

{% tf extensions/mobile.md %}

{% tf extensions/filtercontrol.md %}

{% tf extensions/naturalsorting.md %}